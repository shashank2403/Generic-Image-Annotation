# Generic_Image_Annotation_GUI
### This is a software being developed as the part of the Yogasana classification project under Prof. Rahul Garg, CSE, IITD.

This module is for annotating images in general. It will be used to generate labelled image for human pose estimation in this project although it is quite generic in use.
